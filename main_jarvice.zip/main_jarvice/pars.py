import requests
from bs4 import BeautifulSoup as BS




r = requests.get("https://w127.zona.plus/search/%D0%BE%D0%B4%D0%B8%D0%BD%20%D0%B4%D0%BE%D0%BC%D0%B0")
html = BS(r.text, 'lxml')
a = []
b = []
c = []
b1 = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
a = html.findAll('li', class_='results-item-wrap')
#print(a)
for data in a:
    if data.find('div', itemprop="name") is not None:
        #print(data.text)
        b.append(data.text.lower())

        
for data1 in a:
    if data1.find('span', class_="results-item-year") is not None:
        print(data1.results-item-year)
        


for x in b:
    x = x.replace("\n", "").strip()
    for h in x:
        if h in b1:
            x = x.replace(h, "").strip()
    #print(x)
    c.append(x.lower())

    
g = "один дома"   
for i in c:
    if g in i:
        print(i)


"""for data in a:
    if data.find('div', class_='results-item-title') is not None:
        #print(data.text)
        b.append(data.text.lower())"""

